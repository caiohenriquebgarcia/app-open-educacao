import 'package:flutter/material.dart';

class TelaLogin extends StatefulWidget {
  const TelaLogin({Key? key}) : super(key: key);

  @override
  State<TelaLogin> createState() => _TelaLoginState();
}

class _TelaLoginState extends State<TelaLogin> {
  String _email = "";
  String _senha = "";

  get value => null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          padding: const EdgeInsets.all(25),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const <Widget>[
                      Text("Login", style: TextStyle(fontSize: 22)),
                      Text("Open Educação", style: TextStyle(fontSize: 32))
                    ],
                  )
                ],
              ),
              const SizedBox(height: 20),
              TextFormField(
                decoration: const InputDecoration(
                  labelText: 'Usuário',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),
              TextFormField(
                decoration: const InputDecoration(
                  labelText: 'Senha',
                  border: OutlineInputBorder(),
                  suffixIcon: Icon(Icons.remove_red_eye_sharp),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  //CHECKBOX

                  TextButton(
                      onPressed: () {}, child: const Text("Manter conectado?")),

                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pushNamed('/recuperar');
                    },
                    child: const Text("Recuperar Senha"),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(
                      60), // fromHeight use double.infinity as width and 40 is the height
                ),
                onPressed: () {
                  Navigator.of(context).pushNamed('/principal');
                },
                child: const Text('Acessar', style: TextStyle(fontSize: 18)),
              ),
              const SizedBox(height: 20),
              Row(
                children: <Widget>[
                  TextButton(
                      onPressed: () {
                        Navigator.of(context).pushNamed('/cadastro');
                      },
                      child: const Text("Registrar-se"))
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
