import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class TelaPrincipal extends StatefulWidget {
  const TelaPrincipal({Key? key}) : super(key: key);

  @override
  State<TelaPrincipal> createState() => _TelaPrincipalState();
}

class _TelaPrincipalState extends State<TelaPrincipal> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Open Educação",
        ),
        elevation: 0.0,
      ),
      drawer: const Drawer(),
      body: Center(
        child: Container(
          padding: const EdgeInsets.all(25),
          child: Column(children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                const Text("Área do Aluno"),
                OutlinedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.play_arrow, size: 18),
                  label: const Text("Instruções"),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Column(
              children: <Widget>[
                TextFormField(
                  decoration: const InputDecoration(
                    labelText: "O que você está procurando?",
                    border: OutlineInputBorder(),
                    suffixIcon: Icon(Icons.search),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const <Widget>[
                    Text("Escolher"),
                    const SizedBox(height: 10),
                    Text("Selecione um curso \nque você se interessou."),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const <Widget>[
                    Text("Assistir"),
                    SizedBox(height: 10),
                    Text("Selecione um curso que \nvocê se interessou."),
                  ],
                )
              ],
            ),
            const SizedBox(height: 40),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                const Text(
                  "Vídeos",
                ),
                TextButton(onPressed: () {
                  Navigator.of(context).pushNamed('/tabbar');
                }, child: const Text("Filtrar ⬇")),
              ],
            ),
            const SizedBox(height: 20),
            
          ]),
        ),
      ),
    );
  }
}
